#include "Menu.h"

// Amit Gutfeld		313161481
// Talia Rint		208253286

int main()
{
	Menu menu;
	menu.Start();
}