#include "menu.h"

int main()
{
	Menu menu;
	menu.Start();
}